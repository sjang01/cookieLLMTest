from .arguments import QATrainArguments, QADeployArguments
from .task import QATask
from .corpus import *
from .deploy import get_web_service_app
